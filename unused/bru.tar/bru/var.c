#include <signal.h>

char buf[512];
int nbytes;
int fd = 0;

main()
{

	int done();

	if (signal(SIGSEGV, SIG_IGN) != SIG_IGN)
		signal(SIGSEGV, done);
	for(;;)
	{
	if(read(fd, &nbytes, 2) <= 0) exit(0);
	if(read(fd, buf, (nbytes+1)/2*2) <0) exit(0);
	buf[nbytes]='\n';
	write(1, buf, nbytes+1);
	}
}

done(){ exit(0);}
