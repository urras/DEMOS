char buf[512];
int nbytes;
int fd = 0;

main()
{

	for(;;)
	{
	if(read(fd, &nbytes, 2) <= 0) exit(0);
	if(read(fd, buf, (nbytes+1)/2*2) <0) exit(0);
	write(1, buf, nbytes);
	}
}
