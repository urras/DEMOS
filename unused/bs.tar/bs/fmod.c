double
fmod(x, y)
double x, y;
{
	extern double modf();
	double d;

	if (y == 0.0)
		return (x);
	(void) modf(x / y, &d);
	return (x - d * y);
}
