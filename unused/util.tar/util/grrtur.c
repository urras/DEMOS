
/* function to draw a rectangle from an upper right corner positon */
grrtur(c,r,w,l,color)
int c; /* column coordinate of upper right position */
int r; /* row coordinate of upper right position */
int w; /* width of rectangle */
int l; /* length of rectangle */
int color; /* color of rectangle */
{
int x[5]; /* column coordinates of corner points */
int y[5]; /* row coordinates of corner points */
int i; /* temp loop counter */
/* set up corner points */
x[0]=x[1]=x[4]=c-w;
x[2]=x[3]=c;
y[0]=y[3]=y[4]=r;
y[2]=y[1]=r+l;
/* plot points */
for(i = 0; i < 4; ++i)
  {
  grline(x[i],y[i],x[i+1],y[i+1],color);
  }
return(0);
}
