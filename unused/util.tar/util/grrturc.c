

/* function to draw a color rectangle from an upper right corner position */
grrturc(c,r,w,l,color)
int c; /* column coordinate of upper right position */
int r; /* row coordinate of upper right position */
int w; /* width of rectangle */
int l; /* length of rectangle */
int color; /* color of rectangle */
{
int c1; /* column coordinate of upper left */
int r1; /* row coordinate of upper left */
int c2; /* column coordinate of lower right */
int r2; /* row coordinate of lower right */
/* set points */
c1 = c - w;
r1 = r;
c2 = c;
r2 = r + l;
/* call box fill routine */
grbxfill(c1,r1,c2,r2,color);
return(0);
}
