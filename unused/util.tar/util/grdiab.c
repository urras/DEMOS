
/* function to draw a dot inside a box */
grdiab(c1,r1,color)
int c1; /* column coordinate */
int r1; /* row coordinate */
int color; /* color of box */
{
int m,n,a,col,r[17],c[17],i;
/* check parameters */
getscmod(&m,&n,&a);
if(m == 3) col = 320;
  else if(m == 4) col = 320;
    else col = 640;
/* set up points */
r[0]=r[1]=r[2]=r[3]=r[4]=r1 -2;
r[5]=r[15]=r1 -1;
r[6]=r[16]=r[14]=r1;
r[7]=r[13]=r1 + 1;
r[8]=r[9]=r[10]=r[11]=r[12]=r1 + 2;
c[0]=c[5]=c[6]=c[7]=c[8]=c1 - 2;
c[1]=c[9]=c1 - 1;
c[2]=c[16]=c[10]=c1;
c[3]=c[11]=c1 + 1;
c[4]=c[15]=c[14]=c[13]=c[12]=c1 + 2;
for(i = 0; i < 17; ++i)
  {
  if((r[i] > -1)&&(r[i] < 200)&&(c[i] > -1)&&(c[i] < col))
    {
     dot(c[i],r[i],color);
    }
  }
return(0);
}
