
/* function to print out a horizontal string on graph */
grxlab(t,c,cl,row)
char *t; /* title */
int c; /* color */
int cl; /* column */
int row; /* row */
{
int i,m,n,a,col;
/* check paramters */
getscmod(&m,&n,&a);
if(m == 3) col = 40;
  else if(m == 4) col = 40;
    else col = 80;
/* write title */
for(i = 0; i + cl < col; ++i)
  {
  if(t[i] == '\0') break;
  curlocat(row,i + cl);
  wrtchtty(t[i],c);
  }
return(0);
}
