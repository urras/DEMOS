#include "graphics.h"
#include "colors.h"
#include <stdio.h>
#include <sgtty.h>
#include <signal.h>

/* ������� ��� ������ ����� libplot.a */


int curcolor= WHITE;
int curmode =0;
int curpalette;
static struct sgttya old,new;

Color( ncolor){
	curcolor = ncolor + curpalette*3 ;
	color( curcolor);
}

dot( x,y, ncolor ){
	if( ncolor != curcolor ) Color( ncolor );
	point( x,y );
}

grline( x1,y1,  x2,y2 , ncolor ){
	if( ncolor != curcolor ) Color( ncolor );
	line( x1,y1,  x2,y2 );
}



grbxfill( x1, y1,   x2, y2, ncolor ){
	if( ncolor != curcolor ) Color( ncolor );
	rfill( x1,y1,x2,y2 );
}

#ifdef RFILL
/* � ���������� ��� ��������� �������� ����� */
rfill( x1, y1,   x2, y2 ){
	int i;

	if( y1 < y2 )for( i=y1; i<y2 ; i++ )
		line( x1, i,   x2, i );
	else         for( i=y2; i<y1 ; i++ )
		line( x1, i,   x2, i );
	if( x1 < x2 )for( i=x1; i<x2 ; i++ )
		line(  i,y1,   i,y2 );
	else         for( i=x2; i<x1 ; i++ )
		line(  i,y1,   i,y2 );
}
#endif RFILL

wrtchtty( c,col  ) char c;
{
	char b[2];
	b[0] = c;
	b[1] =0;
	if( col != curcolor ) Color( col);
	label( b);
}

curlocat( i,j ){
/* j - ��� �������
 * i - stroka */

	move( j*8, i*8 + 8 );
}

int onintr( i){
	grafinit( 2,0,0);
	exit( i);
}

grafinit( mode, palette, bakrnd)
int mode; /* 0,2 - alpha */
	  /* 1   - graphics */
int palette;
int bakrnd;     /* background color */
{
	fflush ( stdout);
	if( mode < 0 || mode > 2 ) return -1;
	curpalette = palette;
	signal( SIGINT, onintr);
	switch( mode ){
	case 2:         /* alpha */
	case 0:
		if( curmode != 4 ) break;

		ioctl( 0, TIOCSETA, &old );
		curmode = 2;   /* PC compatible */
		erase();
		closepl();
		break;
	case 1: /* 320 * 200 graphics */
		if( curmode == 0){
		  fprintf( stderr,"Init\n");
		  ioctl( 0,TIOCGETA, &old );
		  new = old;
		  new.sg_flags =  ( old.sg_flags & ~(CRMOD|ECHO|XTABS)) | CBREAK;
		}

		curmode = 4;
		ioctl( 0,TIOCSETA, & new );

		openpl();
		     /*            R G B       */
/*
		colormap( BLACK,   0,0,0 );
		colormap( BLUE ,   0,0,10000);
		colormap( GREEN,   0,10000,0);
		colormap( CYAN ,   0,5000,5000);
		colormap( RED  ,   10000,0,0);
		colormap( MAGENTA, 5000,2500,2500);
		colormap( BROWN,   5000,5000,0);
		colormap( WHITE,   3330,3330,3330);
		colormap( GRAY,    1000,2500,2500);
*/

		space( 0, 320, 320, 0);
		erase();

	  /* BACKGROUND */
	  /* grbxfill( 0,0,319,199, ( bakrnd + (curpalette+1)*3)%16 ); */
	  /*
		box( 0,0,319,199 );
		box( 1,1,318,198 );
	   */
		Color( WHITE);

		break;
	}
	return 0;
}

initgraf( mode, palette, bakrnd){
	return grafinit( mode,palette, bakrnd );
}

randnum( a,b ){
	return a + rand()%( b-a );
}

/* ������� */
setscmod( n ){
	switch( n){
	case 2:
		grafinit( 2,0,0 );
		break;
	case 4:
		grafinit( 1,1,1);
		break;
	}
}

getscmod( a,b,c ) int *a,*b,*c; { *a= curmode ; }
char getkey( p ) char *p; { *p= getchar(); return 0; }

clearkbd(){ fflush( stdin);}
checkkey(){
	long N;
	ioctl( 0, FIONREAD, &N );
	return N==0l ? 0:1 ;
}
