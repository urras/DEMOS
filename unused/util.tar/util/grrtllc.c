

/* function to draw a color rectangle from an lower left corner position */
grrtllc(c,r,w,l,color)
int c; /* column coordinate of lower left position */
int r; /* row coordinate of lower left position */
int w; /* width of rectangle */
int l; /* length of rectangle */
int color; /* color of rectangle */
{
int c1; /* column coordinate of upper left */
int r1; /* row coordinate of upper left */
int c2; /* column coordinate of lower right */
int r2; /* row coordinate of lower right */
/* set points */
c1 = c;
r1 = r-l;
c2 = c + w;
r2=r;
/* call box fill routine */
grbxfill(c1,r1,c2,r2,color);
return(0);
}
