

/* function to draw a polygon (set of lines) from 2 arrays of pts. */
grpoly(c,r,sides,color)
int *c; /* pointer to array of column coordinates */
int *r; /* pointer to array of row coordinates */
int sides; /* number of sides */
int color; /* color of polygon */
{
int i; /* temp loop counter */
for(i = 0; i < sides - 1; ++i)
  {
  grline(c[i],r[i],c[i+1],r[i+1],color);
  }
/* close polygon */
grline(c[0],r[0],c[sides-1],r[sides-1],color);
return(0);
}
