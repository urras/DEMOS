
/* function to draw a color box from an lower right corner position */
grbxlrc(c,r,side,color)
int c; /* column coordinate of lower right corner of box */
int r; /* row coordinate of lower right corner of box */
int side; /* length of side of box */
int color; /* foreground color of line */
{
int c1; /* column coordinate of upper left */
int r1; /* row coordinate of upper left */
int c2; /* column coordinate of lower right */
int r2; /* row coordinate of lower right */
/* set points */
c1 = c - side;
r1 = r - side;
c2 = c;
r2 = r;
 /* call box fill routine */
grbxfill(c1,r1,c2,r2,color);
return(0);
}
