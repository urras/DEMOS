/* function to print out a vertical string */
grylab(r,c,cl,row)
char *r; /* label */
int c; /* color */
int cl; /* column to start at */
int row; /* row to start at */
{
int i;
/* check paramters */
if((c < 0)||(c > 3)) return(-1);
/* write string */
for(i = 0; i + row < 25; ++i)
  {
  if(r[i] == '\0') break;
  curlocat(i + row,cl);
  wrtchtty(r[i],c);
  }
return(0);
}
