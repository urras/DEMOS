#include "graphics.h"

/* function to draw a line from a base point */
grmove(c,r,color)
int c; /* column coordinate of end point */
int r; /* row coordinate of end point */
int color; /* foreground color of line */
{
extern struct plotpos base;
int i;
/* all checks are done by line function */
i = grline(c,r,base.col,base.row,color);
if(i > 0)
  {
  base.row = r;
  base.col = c;
  }
return(i);
}
