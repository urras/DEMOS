
/* function to draw a solid box at a point */
grbx(c1,r1,color)
int c1; /* column coordinate */
int r1; /* row coordinate */
int color; /* color of box */
{
int m,n,a,col,r[9],c[9],i;
/* check parameters */
getscmod(&m,&n,&a);
if(m == 3) col = 320;
  else if(m == 4) col = 320;
    else col = 640;
/* set up points */
r[0]=r[1]=r[2]=r1 - 1;
r[3]=r[4]=r[5] = r1;
r[6]=r[7]=r[8]= r1 + 1;
c[0]=c[3]=c[6]=c1 - 1;
c[1]=c[4]=c[7]=c1;
c[2]=c[5]=c[8]=c1 + 1;
for(i = 0; i < 9; ++i)
  {
  if((r[i] > -1)&&(r[i] < 200)&&(c[i] > -1)&&(c[i] < col))
    {
     dot(c[i],r[i],color);
    }
  }
return(0);
}
