#include "graphics.h"

/* function to draw a line from a base position to a point that is */
/* given as a delta from the base                                  */
grdmove(c,r,color)
int c; /* delta offset from base column */
int r; /* delta offset from the base row */
int color; /* foreground color of line */
{
extern struct plotpos base;
int i;
/* calculate end point */
r = base.row + r;
c = base.col + c;
/* all checks are done by the line function */
i = grline(c,r,base.col,base.row,color);
if(i > 0)
  {
  base.row = r;
  base.col = c;
  }
return(i);
}
