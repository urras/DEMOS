/* function to draw passed quadrant(s) of an ellipse using aspect */
grelipQa(quad,x0,y0,coldiff,rowdiff,c,fill,an,ad)
int quad; /* quadrant(s) to plot */
int x0; /* column corrdinate of center of ellipse */
int y0; /* row coordinate of center of ellipse */
int coldiff; /* size of ellipse along x axis */
int rowdiff; /* size of ellipse along y axis */
int c; /* color of ellipse */
int fill; /* fill ellipse with color (1-yes,0-no) */
int an; /* numerator of the aspect ratio to use */
int ad; /* denominator of the aspect ratio to use */
{
int xe[5],ye[5],ax,ay,i,j,k,l,dx[4][3],dy[4][3],px[3],py[3],x,y;
double df[3],a,b,tx,ty,tdx,tdy;
int f[200][2],top[4],bot[4]; /* fill variables */
char q[4],flag;
ax = coldiff/2;
rowdiff = (rowdiff * an)/ad;
ay = rowdiff/2;
xe[0]=xe[4]=x0+ax;
xe[2]=x0-ax;
xe[1]=xe[3]=x0;
ye[0]=ye[4]=ye[2]=y0;
ye[1]=y0-ay;
ye[3]=y0+ay;
a=ax*ax;
b=ay*ay;
dx[0][0]=dx[0][1]=dx[1][1]=dx[1][2]= -1;
dx[0][2]=dx[1][0]=dx[2][2]=dx[3][0]=0;
dx[2][0]=dx[2][1]=dx[3][1]=dx[3][2]=1;
dy[0][1]=dy[0][2]=dy[3][0]=dy[3][1]= -1;
dy[0][0]=dy[1][2]=dy[2][0]=dy[3][2]=0;
dy[1][0]=dy[1][1]=dy[2][1]=dy[2][2]=1;
if(fill == 1)
  {
  for(i = 0; i < 200; ++i)
    {
    f[i][0]=f[i][1]= -1;
    }
  for(i = 0; i < 4; ++i)
    {
    top[i] = 500;
    bot[i] = -1;
    }
  }
for(i = 8,j = 3; i > 0; i = i / 2,--j)
  {
  if(i <= quad)
    {
    q[j] = 'y';
    quad = quad - i;
    }
    else q[j] = 'n';
  }
for(l = 0; l < 4; ++l)
  {
  if(q[l] != 'y') continue;
  x = xe[l];
  y = ye[l];
  flag = 'y';
  for( ; ;)
    {
    if(flag == 'y')
      {
      flag = 'n';
      }
      else
      {
      for(i = 0; i < 3; ++i)
	{
	px[i] = x + dx[l][i] - x0;
	py[i] = y + dy[l][i] - y0;
	tx = px[i] * px[i];
	ty = py[i] * py[i];
	tdx = tx/a;
	tdy = ty/b;
	df[i] = tdx + tdy - 1;
	if(df[i] < 0) df[i] = df[i] * -1;
	}
      k = 0;
      for(j = 1; j < 3; ++j) if(df[k] > df[j]) k = j;
      x = x + dx[l][k];
      y = y + dy[l][k];
      }
    dot(x,y,c);
    if(fill == 1)
      {
      if(f[y][0] == -1)
	{
	if(x0 < x) f[y][0] = x0;
	  else f[y][0] = x;
	if(x0 > x) f[y][1] = x0;
	  else f[y][1] = x;
	}
	else
	{
	if(f[y][0] > x) f[y][0] = x;
	if(f[y][1] < x) f[y][1] = x;
	}
      if(top[l] > y) top[l] = y;
      if(bot[l] < y) bot[l] = y;
      }
    if((x == xe[l+1])&&(y == ye[l+1])) break;
    }
  }
if(fill == 1)
  {
  for(l = 0; l < 4; ++l)
    {
    if(q[l] != 'y') continue;
    for(i = top[l]; i < bot[l]+1; ++i)
      {
      if(f[i][0] == -1)
	{
	for(j = 1; i - j > -1; ++j)
	  {
	  if(f[i-j][0] != -1)
	    {
	    grline(f[i-j][0],i,f[i-j][1],i,c);
	    break;
	    }
	  }
	}
	else grline(f[i][0],i,f[i][1],i,c);
      }
    }
  }
}
