#include "graphics.h"

/* function to draw a line from a base point and update fill array for arc */
gramov(c,r,color,f,top,bot)
int c; /* column coordinate of end point */
int r; /* row coordinate of end point */
int color; /* foreground color of line */
int f[200][2];
int *top;
int *bot;
{
extern struct plotpos base;
int i;
/* all checks are done by line function */
i = grarcl(c,r,base.col,base.row,color,&f[0][0],top,bot);
if(i > 0)
  {
  base.row = r;
  base.col = c;
  }
return(i);
}
