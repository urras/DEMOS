

/* function to draw a color box from a lower left corner position */
grbxllc(c,r,l,color)
int c; /* column coordinate of lower left position */
int r; /* row coordinate of lower left position */
int l; /* length of side of box */
int color; /* color of box */
{
int c1; /* column coordinate of upper left */
int r1; /* row coordinate of upper left */
int c2; /* column coordinate of lower right */
int r2; /* row coordinate of lower right */
/* set points */
c1 = c;
r1 = r-l;
c2 = c + l;
r2=r;
/* call box fill routine */
grbxfill(c1,r1,c2,r2,color);
return(0);
}
