
/* function to draw a color rectangle from a center point position */
grrtctc(c,r,w,l,color)
int c; /* column coordinate of center point */
int r; /* row coordinate of center point */
int w; /* width of rectangle */
int l; /* length of rectangle */
int color; /* color of rectangle */
{
int c1; /* column coordinate of upper left */
int r1; /* row coordinate of upper left */
int c2; /* column coordinate of lower right */
int r2; /* row coordinate of lower right */
/* set points */
c1 = c-(w/2);
r1=r-(l/2);
c2=c+(w/2);
r2=r+(l/2);
/* call box fill routine */
grbxfill(c1,r1,c2,r2,color);
return(0);
}
