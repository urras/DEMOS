/* demo3.c - graphics part of demo             */
#include "graphics.h"

int i,k,d1,d2,d3;
int r1x[20],r1y[20],r2x[20],r2y[20],r3x[20],r3y[20];
int r4x[20],r4y[20];
struct plotpos base;
int l1[10] = {177,50,161,50,131,68,91,108,41,158};
int l2[10] = {177,50,161,60,161,80,145,96,105,256};
int l3[10] = {177,50,177,53,160,89,100,149,40,209};
int dx[7] = {110,80,165,30,95,75,165};
int dy[7] = {41,60,110,160,210,260,305};


main()
{
int r,c,col,f;
char x[80];
 for(i = 0; i < 10; ++i)
  {
  r1x[i] = 50 + randnum(0,1000) % 120;
  r1y[i] = 57 + randnum(0,1000) % 260;
  r2x[i] = 50 + randnum(0,1000) % 120;
  r2y[i] = 57 + randnum(0,1000) % 260;
  r3x[i] = 50 + randnum(0,1000) % 120;
  r3y[i] = 57 + randnum(0,1000) % 260;
  r4x[i] = 50 + randnum(0,1000) % 120;
  r4y[i] = 57 + randnum(0,1000) % 260;
  }

menu:
initgraf(1,1,0);

grxlab("ESSENTIAL SOFTWARE GRAPHICS DEMO",3,3,1);
grxlab("GRAPHICS MENU",3,3,3);
grxlab("-------------",3,3,4);
grxlab("1.BAR GRAPH",3,3,5);
grxlab("2.COMPONENT BAR GRAPH",3,3,6);
grxlab("3.SCATTER GRAPH",3,3,7);
grxlab("4.ABOVE/BELOW LINE GRAPH",3,3,8);
grxlab("5.LINE GRAPH",3,3,9);
grxlab("6.PIE GRAPH",3,3,10);
grxlab("7.MULTIPLE GRAPHS ON ONE SCREEN",3,3,11);
grxlab("ENTER # OF GRAPH TO BE DISPLAYED",2,3,13);
grxlab("OR ANY OTHER KEY TO EXIT:",2,3,14);
grxlab("AFTER VIEWING A GRAPH, HIT ANY",1,3,20);
grxlab("KEY TO RETURN TO GRAPHICS MENU",1,3,21);
f = 0;
r = 0;
c = 0;
col = 1;
clearkbd();
for( ; ; )
  {
  if((i = checkkey()) == 1) break;
  dot(c,r,col);
  if(f == 0)
    {
    ++c;
    if(c == 320)
      {
      f = 1;
      c = 319;
      if(col == 3) col = 1;
	else ++col;
      }
    continue;
    }
  if(f == 1)
    {
    ++r;
    if(r == 200)
      {
      f = 2;
      r = 199;
      if(col == 3) col = 1;
	else ++col;
      }
    continue;
    }
  if(f == 2)
    {
    --c;
    if(c == -1)
      {
      f = 3;
      c = 0;
      if(col == 3) col = 1;
       else ++col;
      }
    continue;
    }
  if(f == 3)
    {
    --r;
    if(r == -1)
      {
      f = 0;
      r = 0;
      if(col == 3) col = 1;
	else ++col;
      }
    continue;
    }
  }
i = getkey(&k);
if((k < 49)||(k > 55)) goto done;
if(i != 0) goto done;


switch(k)
  {
  case 49: f1(); break;
  case 50: f2(); break;
  case 51: f3(); break;
  case 52: f4(); break;
  case 53: f5(); break;
  case 54: f6(); break;
  case 55: f7(); break;
  }
goto menu;
done:
setscmod(2);
}


f1()
{
initgraf(1,1,1);
/* bar graph */
grylab("% OF SALES",1,0,6);
grxlab("YEAR",1,18,24);
grxlab("1984",1,10,23);
grxlab("1983",1,21,23);
grxlab("1982",1,32,23);
grline(49,25,49,180,1);
grline(49,180,319,180,1);
grxlab("BAR GRAPH",1,15,0);
grxlab("KEY",1,32,1);
grxlab("PRODUCT 1",1,30,2);
grxlab("PRODUCT 2",1,30,3);
grxlab("PRODUCT 3",1,30,4);
grshdn(224,17,232,17,24,1,1);
grshdn(224,25,232,25,32,2,2);
grshdn(224,33,232,33,40,3,3);
grline(220,6,319,6,1);
grline(220,6,220,42,1);
grline(220,42,319,42,1);
grline(319,42,319,6,1);
for(i = 176; i > 25; i = i - 8)
  {
  if(i != 176) grxlab("-",1,5,(i / 8));
  if((i % 16) == 0)
    {
    switch((i /16))
      {
      case 10: grxlab("10",1,3,(i / 8)); break;
      case 9: grxlab("20",1,3,(i / 8)); break;
      case 8: grxlab("30",1,3,(i / 8)); break;
      case 7: grxlab("40",1,3,(i / 8)); break;
      case 6: grxlab("50",1,3,(i / 8)); break;
      case 5: grxlab("60",1,3,(i / 8)); break;
      case 4: grxlab("70",1,3,(i / 8)); break;
      case 3: grxlab("80",1,3,(i / 8)); break;
      case 2: grxlab("90",1,3,(i / 8)); break;
      }
    }
  }
/* generate bars of histogram using grbxfill */

grbxfill(56,86,80,180,1);
grbxfill(81,160,105,180,2);
grbxfill(106,140,130,180,3);
grbxfill(146,95,170,180,1);
grbxfill(171,138,195,180,2);
grbxfill(196,160,220,180,3);
grbxfill(236,100,260,180,1);
grbxfill(261,130,285,180,2);
grbxfill(286,170,310,180,3);

i = getkey(&k);
}


f2()
{
/* component bar graph */
initgraf(1,1,1);
grylab("% OF SALES",1,0,6);
grxlab("YEAR",1,13,24);
grxlab("1984",1,7,23);
grxlab("1983",1,13,23);
grxlab("1982",1,19,23);
grline(49,19,49,180,1);
grline(49,180,182,180,1);
grxlab("COMPONENT BAR GRAPH",1,7,0);
grxlab("KEY",1,32,1);
grxlab("PRODUCT 1",1,30,2);
grxlab("PRODUCT 2",1,30,3);
grxlab("PRODUCT 3",1,30,4);
grshdn(224,17,232,17,24,1,1);
grshdn(224,25,232,25,32,2,2);
grshdn(224,33,232,33,40,3,3);
grline(20;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1983"1
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp1);
gryo 1933 = 0  rinitar  TO2,2)ill(QISo d*/

ONEDNY(2247 5,3){
  c1(HEsw2322);
9,49( =  % 2UL3);177);
grxlab("P
sreaba /) % 0,80 GRAONEFTE�,d80("�bxf9e0;
 = 3)ey(3;y(&(); brea% O6,};
i
s��

fs1983"1601
  i;
grxlab(" ;3)f = 3; br1,3,;
      ca�� {
9el200k;
       {24,25kb3,23�2611601"{
    s86mp