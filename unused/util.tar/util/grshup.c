
/* function to draw a line between two points and shade up to indicated row */
grshup(c1,r1,c2,r2,r3,lc,sc)
int c1; /* column coordinate of first point */
int r1; /* row coordinate of first point */
int c2; /* column coordinate of second point */
int r2; /* row coordinate of second point */
int r3; /* top row to shade to */
int lc; /* color of line */
int sc; /* color of shade */
{
int dr; /* delta r */
int dc; /* delta c */
int rem; /* remainder of slope */
int r; /* row coordinate to write out */
int c; /* column coordinate to write out */
int i; /* counter of # of points written out */
int j; /* temp counter of incrementing remainder */
int ir; /* increment value of row */
int ic; /* increment value of column */
/* get delta r and c */
dr = ((r1-r2)<0?-(r1-r2):(r1-r2));
dc = ((c1-c2)<0?-(c1-c2):(c1-c2));
/* check that we aren't writing out just one point */
if((dr == 0)&&(dc == 0))
  {
  dot(c1,r1,lc);
  if((r1 - 1) > r3) grline(c1,r1 - 1,c1,r3,sc);
  return(1);
  }
/* which way does the slope go? */
if(dr > dc) goto vertical;
r = r1;
c = c1;
if(c1 > c2) ic = -1;
  else ic = 1;
if(r1 > r2) ir = -1;
  else ir = 1;
/* get slopes remainder */
rem = dr % dc;
/* write out start point */
dot(c1,r1,lc);
if((r1 - 1) > r3) grline(c1,r1 - 1,c1,r3,sc);
/* check for diagonal */
if(dc == dr)
  {
  j = 1;
  dc = 0;
  }
  else j = dc / 2;
/* start loop for line slopes > 1 */
for(i = 1; ; ++i)
  {
  /* are we done ? */
  if((r == r2)&&(c == c2)) return(i);
  j = j + rem;
  if(j > dc)
    {
    r = r + ir;
    j = j - dc;
    }
  c = c + ic;
  dot(c,r,lc);
  if((r - 1) > r3) grline(c,r - 1,c,r3,sc);
  }
vertical:
r = r1;
c = c1;
if(c1 > c2) ic = -1;
  else ic = 1;
if(r1 > r2) ir = -1;
  else ir = 1;
/* get slopes remainder */
rem = dc % dr;
/* write out start point */
dot(c1,r1,lc);
if((r1 - 1) > r3) grline(c1,r1 - 1,c1,r3,sc);
j = dr / 2;
/* start loop for line slopes < or = 1 */
for(i = 1; ; ++i)
  {
  /* are we done ? */
  if((r == r2)&&(c == c2)) return(i);
  j = j + rem;
  if(j > dr)
    {
    c = c + ic;
    j = j - dr;
    }
  r = r + ir;
  dot(c,r,lc);
  if((r - 1) > r3) grline(c,r - 1,c,r3,sc);
  }
}
