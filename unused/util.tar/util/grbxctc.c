

/* function to draw a color box from a center point position */
grbxctc(c,r,side,color)
int c; /* column coordinate of center point */
int r; /* row coordinate of center point */
int side; /* length of side of box */
int color; /* foreground color of line */
{
int c1; /* column coordinate of upper left */
int r1; /* row coordinate of upper left */
int c2; /* column coordinate of lower right */
int r2; /* row coordinate of lower right */
/* set points */
c1 = c-(side/2);
r1 = r-(side/2);
c2 = c+(side/2);
r2 = r + (side/2);
 /* call box fill routine */
grbxfill(c1,r1,c2,r2,color);
return(0);
}
