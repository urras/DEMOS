
/*  structure for DOS functions that use/return file specifications */
struct filedata {
  char reserved[21]; /* for DOS on subsequent find next (clfndnxt) calls */
  char atrib;        /* one byte attribute of file found */
  unsigned filetime; /* last update time */
  unsigned filedate; /* date last updated */
  long filesize;     /* 4 bytes containing file size in bytes */
  char filename[13]; /* filename just as you would enter it for DOS command */
};
