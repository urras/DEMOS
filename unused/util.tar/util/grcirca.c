#include "graphics.h"
/* function to draw a line circle using a passed aspect ratio */
grcirca(x0,y0,r,d,c,an,ad)
int x0; /* column coordinate of center of circle */
int y0; /* row coordinate of center of circle */
int r; /* radius of circle */
int d; /* angle increment in degrees */
int c; /* color of circle */
int an; /* numerator of the aspect ratio to use */
int ad; /* denominator of the aspect ratio to use */
{
extern struct plotpos base;
int y,x,i; /* temp variables */
float grtrig(); /* sin,cos function */
base.row = y0;
base.col = x0 + r;
for(i = 1; i < 361; i = i + d)
  {
  y =((r * -1) * grtrig(i,0) * an)/ad;
  x = r * grtrig(i,1);
  y = y0 + y;
  x = x0 + x;
  grmove(x,y,c);
  }
/* make sure circle is closed */
y = (r * -1) * grtrig(360,0);
x = r * grtrig(360,1);
y = y0 + y;
x = x0 + x;
grmove(x,y,c);
return(0);
}
