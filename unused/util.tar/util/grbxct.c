
/* function to draw a box from a center point position */
grbxct(c,r,side,color)
int c; /* column coordinate of center point */
int r; /* row coordinate of center point */
int side; /* length of side of box */
int color; /* foreground color of box */
{
int x[5]; /* column coordinates of corner points */
int y[5]; /* row coordinates of corner points */
int i; /* temp loop counter */
/* set up corner points */
x[0]=x[4]=x[1]=c-(side/2);
x[2]=x[3]=c+(side/2);
y[0]=y[3]=y[4]=r-(side/2);
y[1]=y[2]=r+(side/2);
/* plot points */
for(i = 0; i < 4; ++i)
  {
  grline(x[i],y[i],x[i+1],y[i+1],color);
  }
return(0);
}
