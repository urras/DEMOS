/* header file holding the needed graphics definitions */
struct plotpos
  {
  int row; /* row coordinate */
  int col; /* col coordinate */
  };
