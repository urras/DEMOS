
/* function to draw a "x" at a point */
grwx(c1,r1,color)
int c1; /* column coordinate */
int r1; /* row coordinate */
int color; /* color of x */
{
int m,n,a,col,r[5],c[5],i;
/* check parameters */
getscmod(&m,&n,&a);
if(m == 3) col = 320;
  else if(m == 4) col = 320;
    else col = 640;
/* set up points */
r[0]=r[3]=r1 - 1;
r[1]=r[2]=r1 + 1;
r[4]=r1;
c[0]=c[1]=c1 - 1;
c[2]=c[3]=c1 + 1;
c[4] = c1;
for(i = 0; i < 5; ++i)
  {
  if((r[i] > -1)&&(r[i] < 200)&&(c[i] > -1)&&(c[i] < col))
    {
    dot(c[i],r[i],color);
    }
  }
return(0);
}
