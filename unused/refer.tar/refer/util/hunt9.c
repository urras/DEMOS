remote(in, out)
	char *in, *out;
{
/* "in" is a long distance file name: get it */
;
}
