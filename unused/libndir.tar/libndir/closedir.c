static char sccsid[] = "@(#)closedir.c 4.2 3/10/82";

#include <sys/types.h>
#include <dir.h>

/*
 * close a directory.
 */
void
closedir(dirp)
	register DIR *dirp;
{
	close(dirp->dd_fd);
	dirp->dd_fd = -1;
	dirp->dd_loc = 0;
	free(dirp);
}
